import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import "./globals.css"
import Chatbot from "@/components/chatbot"

export const metadata: Metadata = {
  title: "CAB 5 - Premium Taxi Service",
  description:
    "Reliable taxi service with professional drivers, clean vehicles, and 24/7 availability. Book your ride with CAB 5 today.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <style>{`
html {
  font-family: ${GeistSans.style.fontFamily};
  --font-sans: ${GeistSans.variable};
  --font-mono: ${GeistMono.variable};
}
        `}</style>
      </head>
      <body>
        {children}
        <Chatbot />
      </body>
    </html>
  )
}
