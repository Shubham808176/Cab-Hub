"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Navigation, Phone, ArrowLeft, Calendar, Car, Users, CreditCard } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function BookingPage() {
  const router = useRouter()
  const [pickupLocation, setPickupLocation] = useState("")
  const [dropoffLocation, setDropoffLocation] = useState("")
  const [rideDate, setRideDate] = useState("")
  const [rideTime, setRideTime] = useState("")
  const [vehicleType, setVehicleType] = useState("")
  const [passengers, setPassengers] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("")
  const [specialRequests, setSpecialRequests] = useState("")

  const vehicleTypes = [
    {
      id: "auto",
      name: "Auto Rickshaw",
      price: "₹50-80", // Updated pricing to Indian Rupees
      icon: "🛺",
      description: "3-wheeler, budget-friendly",
    },
    {
      id: "standard",
      name: "Standard Taxi",
      price: "₹120-180", // Updated pricing to Indian Rupees
      icon: "🚗",
      description: "Comfortable sedan, 4 seats",
    },
    {
      id: "premium",
      name: "Premium Car",
      price: "₹250-350", // Updated pricing to Indian Rupees
      icon: "🚙",
      description: "Luxury vehicle, premium comfort",
    },
    {
      id: "suv",
      name: "SUV",
      price: "₹300-450", // Updated pricing to Indian Rupees
      icon: "🚐",
      description: "Large SUV, 6-7 seats",
    },
    {
      id: "van",
      name: "Mini Van",
      price: "₹400-550", // Updated pricing to Indian Rupees
      icon: "🚌",
      description: "Group travel, 8+ seats",
    },
    {
      id: "accessible",
      name: "Wheelchair Accessible",
      price: "₹180-280", // Updated pricing to Indian Rupees
      icon: "♿",
      description: "Specially equipped vehicle",
    },
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Generate random 4-digit code
    const trackingCode = Math.floor(1000 + Math.random() * 9000).toString()

    console.log("[v0] Booking submitted:", {
      pickupLocation,
      dropoffLocation,
      rideDate,
      rideTime,
      vehicleType,
      passengers,
      phoneNumber,
      paymentMethod,
      specialRequests,
      trackingCode,
    })

    // Store booking data in sessionStorage for tracking page
    const bookingData = {
      pickupLocation,
      dropoffLocation,
      rideDate,
      rideTime,
      vehicleType,
      passengers,
      phoneNumber,
      paymentMethod,
      specialRequests,
      trackingCode,
    }

    sessionStorage.setItem("bookingData", JSON.stringify(bookingData))

    // Redirect to tracking page
    router.push(`/track/${trackingCode}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/cab5-logo.png" alt="CAB 5 Logo" width={60} height={60} className="object-contain" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">CAB 5</h1>
              <p className="text-sm text-muted-foreground">Premium Taxi Service</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-yellow-600" />
              <span className="font-semibold">Call: (555) 123-TAXI</span>
            </div>
            <Link href="/">
              <Button variant="outline" className="border-yellow-500 text-yellow-700 hover:bg-yellow-50 bg-transparent">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Booking Form Section */}
      <section className="py-20 bg-gradient-to-br from-yellow-50 to-yellow-100">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-foreground mb-4">Book Your Ride</h2>
              <p className="text-xl text-muted-foreground">Enter your ride details to get started</p>
            </div>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-center">Ride Details</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="pickup" className="text-lg font-semibold flex items-center gap-2">
                      <Navigation className="h-5 w-5 text-yellow-600" />
                      Current Location (Pickup)
                    </Label>
                    <Input
                      id="pickup"
                      type="text"
                      placeholder="Enter your pickup address..."
                      value={pickupLocation}
                      onChange={(e) => setPickupLocation(e.target.value)}
                      className="text-lg py-6 border-2 focus:border-yellow-500"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dropoff" className="text-lg font-semibold flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-yellow-600" />
                      Drop-off Location
                    </Label>
                    <Input
                      id="dropoff"
                      type="text"
                      placeholder="Enter your destination address..."
                      value={dropoffLocation}
                      onChange={(e) => setDropoffLocation(e.target.value)}
                      className="text-lg py-6 border-2 focus:border-yellow-500"
                      required
                    />
                  </div>

                  {/* Date and time selection */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date" className="text-lg font-semibold flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-yellow-600" />
                        Date
                      </Label>
                      <Input
                        id="date"
                        type="date"
                        value={rideDate}
                        onChange={(e) => setRideDate(e.target.value)}
                        className="text-lg py-6 border-2 focus:border-yellow-500"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="time" className="text-lg font-semibold">
                        Time
                      </Label>
                      <Input
                        id="time"
                        type="time"
                        value={rideTime}
                        onChange={(e) => setRideTime(e.target.value)}
                        className="text-lg py-6 border-2 focus:border-yellow-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-lg font-semibold flex items-center gap-2">
                      <Users className="h-5 w-5 text-yellow-600" />
                      Number of Passengers
                    </Label>
                    <Select value={passengers} onValueChange={setPassengers} required>
                      <SelectTrigger className="text-lg py-6 border-2 focus:border-yellow-500">
                        <SelectValue placeholder="Number of passengers" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Passenger</SelectItem>
                        <SelectItem value="2">2 Passengers</SelectItem>
                        <SelectItem value="3">3 Passengers</SelectItem>
                        <SelectItem value="4">4 Passengers</SelectItem>
                        <SelectItem value="5">5 Passengers</SelectItem>
                        <SelectItem value="6">6 Passengers</SelectItem>
                        <SelectItem value="7">7 Passengers</SelectItem>
                        <SelectItem value="8+">8+ Passengers</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Contact information */}
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-lg font-semibold flex items-center gap-2">
                      <Phone className="h-5 w-5 text-yellow-600" />
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter your phone number..."
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="text-lg py-6 border-2 focus:border-yellow-500"
                      required
                    />
                  </div>

                  {/* Payment method selection */}
                  <div className="space-y-2">
                    <Label className="text-lg font-semibold flex items-center gap-2">
                      <CreditCard className="h-5 w-5 text-yellow-600" />
                      Payment Method
                    </Label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod} required>
                      <SelectTrigger className="text-lg py-6 border-2 focus:border-yellow-500">
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                        <SelectItem value="app">Mobile App Payment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Special requests field */}
                  <div className="space-y-2">
                    <Label htmlFor="requests" className="text-lg font-semibold">
                      Special Requests (Optional)
                    </Label>
                    <Textarea
                      id="requests"
                      placeholder="Child seat, pet-friendly, extra stops, etc..."
                      value={specialRequests}
                      onChange={(e) => setSpecialRequests(e.target.value)}
                      className="border-2 focus:border-yellow-500 min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-4">
                    <Label className="text-lg font-semibold flex items-center gap-2">
                      <Car className="h-5 w-5 text-yellow-600" />
                      Choose Your Vehicle
                    </Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {vehicleTypes.map((vehicle) => (
                        <div
                          key={vehicle.id}
                          className={`border-2 rounded-lg p-4 cursor-pointer transition-all hover:border-yellow-500 ${
                            vehicleType === vehicle.id ? "border-yellow-500 bg-yellow-50" : "border-gray-200 bg-white"
                          }`}
                          onClick={() => setVehicleType(vehicle.id)}
                        >
                          <div className="flex items-center gap-3 mb-2">
                            <span className="text-2xl">{vehicle.icon}</span>
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg">{vehicle.name}</h3>
                              <p className="text-sm text-muted-foreground">{vehicle.description}</p>
                            </div>
                            <div className="text-right">
                              <span className="text-lg font-bold text-yellow-600">{vehicle.price}</span>
                              <p className="text-xs text-muted-foreground">Estimated</p>
                            </div>
                          </div>
                          <input
                            type="radio"
                            name="vehicleType"
                            value={vehicle.id}
                            checked={vehicleType === vehicle.id}
                            onChange={() => setVehicleType(vehicle.id)}
                            className="sr-only"
                            required
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-6">
                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold text-lg py-6"
                    >
                      Request Cab
                    </Button>
                  </div>
                </form>

                <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">What happens next?</h3>
                  <div className="space-y-2 text-muted-foreground">
                    <p>• We'll call you within 2 minutes to confirm your booking</p>
                    <p>• Your driver will arrive at the pickup location</p>
                    <p>• Enjoy your safe and comfortable ride with CAB 5</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="text-center mt-8">
              <p className="text-muted-foreground mb-4">Need immediate assistance?</p>
              <Button size="lg" className="bg-black hover:bg-gray-800 text-white font-semibold">
                <Phone className="mr-2 h-5 w-5" />
                Call (555) 123-TAXI
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
