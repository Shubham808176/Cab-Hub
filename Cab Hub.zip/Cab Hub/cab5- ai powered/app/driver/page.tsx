"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Car, Star, CheckCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function DriverPortal() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [activeTab, setActiveTab] = useState("login")
  const [vehicles, setVehicles] = useState([
    {
      id: 1,
      type: "Standard Taxi",
      model: "Maruti Suzuki Swift Dzire",
      year: "2022",
      plateNumber: "DL 01 AB 1234",
      status: "Active",
      rating: 4.8,
      trips: 1250,
    },
  ])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoggedIn(true)
  }

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoggedIn(true)
    setActiveTab("dashboard")
  }

  const handleAddVehicle = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const newVehicle = {
      id: vehicles.length + 1,
      type: formData.get("vehicleType") as string,
      model: formData.get("vehicleModel") as string,
      year: formData.get("vehicleYear") as string,
      plateNumber: formData.get("plateNumber") as string,
      status: "Pending Approval",
      rating: 0,
      trips: 0,
    }
    setVehicles([...vehicles, newVehicle])
    setActiveTab("dashboard")
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <Link href="/" className="flex items-center space-x-2">
              <Image src="/cab5-logo.png" alt="CAB 5" width={60} height={60} />
              <span className="text-2xl font-bold text-gray-900">CAB 5 Driver Portal</span>
            </Link>
            <Link href="/">
              <Button variant="outline">Back to Home</Button>
            </Link>
          </div>

          <div className="max-w-md mx-auto">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle>Driver Login</CardTitle>
                    <CardDescription>Sign in to your driver account</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="driver@example.com" required />
                      </div>
                      <div>
                        <Label htmlFor="password">Password</Label>
                        <Input id="password" type="password" required />
                      </div>
                      <Button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-600">
                        Sign In
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle>Join CAB 5 as Driver</CardTitle>
                    <CardDescription>Start earning with your vehicle today</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleRegister} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="firstName">First Name</Label>
                          <Input id="firstName" placeholder="John" required />
                        </div>
                        <div>
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input id="lastName" placeholder="Doe" required />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" type="tel" placeholder="+91 98765 43210" required />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="driver@example.com" required />
                      </div>
                      <div>
                        <Label htmlFor="license">Driving License Number</Label>
                        <Input id="license" placeholder="DL-1420110012345" required />
                      </div>
                      <div>
                        <Label htmlFor="address">Address</Label>
                        <Textarea id="address" placeholder="Your complete address" required />
                      </div>
                      <div>
                        <Label htmlFor="password">Password</Label>
                        <Input id="password" type="password" required />
                      </div>
                      <Button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-600">
                        Register as Driver
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2">
            <Image src="/cab5-logo.png" alt="CAB 5" width={60} height={60} />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Driver Dashboard</h1>
              <p className="text-gray-600">Welcome back, John Doe</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => setIsLoggedIn(false)}>
              Logout
            </Button>
            <Link href="/">
              <Button variant="outline">Home</Button>
            </Link>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="vehicles">My Vehicles</TabsTrigger>
            <TabsTrigger value="add-vehicle">Add Vehicle</TabsTrigger>
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Car className="h-8 w-8 text-yellow-500" />
                    <div>
                      <p className="text-2xl font-bold">{vehicles.length}</p>
                      <p className="text-gray-600">Active Vehicles</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Star className="h-8 w-8 text-yellow-500" />
                    <div>
                      <p className="text-2xl font-bold">4.8</p>
                      <p className="text-gray-600">Average Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-8 w-8 text-green-500" />
                    <div>
                      <p className="text-2xl font-bold">1,250</p>
                      <p className="text-gray-600">Total Trips</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-medium">Trip Completed</p>
                      <p className="text-sm text-gray-600">Connaught Place to IGI Airport</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">₹450</p>
                      <p className="text-sm text-gray-600">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium">New Booking</p>
                      <p className="text-sm text-gray-600">Karol Bagh to Gurgaon</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-blue-600">₹380</p>
                      <p className="text-sm text-gray-600">5 hours ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vehicles">
            <div className="grid gap-6">
              {vehicles.map((vehicle) => (
                <Card key={vehicle.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Car className="h-12 w-12 text-yellow-500" />
                        <div>
                          <h3 className="text-lg font-semibold">{vehicle.model}</h3>
                          <p className="text-gray-600">
                            {vehicle.type} • {vehicle.year}
                          </p>
                          <p className="text-sm text-gray-500">Plate: {vehicle.plateNumber}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={vehicle.status === "Active" ? "default" : "secondary"}>{vehicle.status}</Badge>
                        <div className="mt-2">
                          <p className="text-sm text-gray-600">Rating: {vehicle.rating}/5</p>
                          <p className="text-sm text-gray-600">Trips: {vehicle.trips}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="add-vehicle">
            <Card>
              <CardHeader>
                <CardTitle>Add New Vehicle</CardTitle>
                <CardDescription>Register a new vehicle to start earning more</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddVehicle} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="vehicleType">Vehicle Type</Label>
                      <Select name="vehicleType" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select vehicle type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Auto Rickshaw">Auto Rickshaw</SelectItem>
                          <SelectItem value="Standard Taxi">Standard Taxi</SelectItem>
                          <SelectItem value="Premium Car">Premium Car</SelectItem>
                          <SelectItem value="SUV">SUV</SelectItem>
                          <SelectItem value="Mini Van">Mini Van</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="vehicleModel">Vehicle Model</Label>
                      <Input name="vehicleModel" placeholder="e.g., Maruti Swift Dzire" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="vehicleYear">Year</Label>
                      <Input name="vehicleYear" placeholder="e.g., 2022" required />
                    </div>
                    <div>
                      <Label htmlFor="plateNumber">License Plate</Label>
                      <Input name="plateNumber" placeholder="e.g., DL 01 AB 1234" required />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="documents">Upload Documents</Label>
                    <Input type="file" multiple accept=".pdf,.jpg,.png" />
                    <p className="text-sm text-gray-600 mt-1">Upload RC, Insurance, and Fitness Certificate</p>
                  </div>
                  <Button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-600">
                    Add Vehicle
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earnings">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Today's Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">₹1,250</p>
                  <p className="text-gray-600">5 trips completed</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>This Week</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-blue-600">₹8,750</p>
                  <p className="text-gray-600">32 trips completed</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Earnings History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { date: "2024-01-15", amount: 1250, trips: 5 },
                    { date: "2024-01-14", amount: 980, trips: 4 },
                    { date: "2024-01-13", amount: 1450, trips: 6 },
                    { date: "2024-01-12", amount: 1100, trips: 5 },
                  ].map((day, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{day.date}</p>
                        <p className="text-sm text-gray-600">{day.trips} trips</p>
                      </div>
                      <p className="font-bold text-green-600">₹{day.amount}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
