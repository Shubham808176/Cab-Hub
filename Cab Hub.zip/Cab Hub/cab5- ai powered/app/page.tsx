import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Phone, Clock, MapPin, Shield, Zap } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image src="/cab5-logo.png" alt="CAB 5 Logo" width={60} height={60} className="object-contain" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">CAB 5</h1>
              <p className="text-sm text-muted-foreground">Premium Taxi Service</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-yellow-600" />
              <span className="font-semibold">Call: (555) 123-TAXI</span>
            </div>
            <Link href="/driver">
              <Button variant="outline" className="border-yellow-500 text-yellow-700 hover:bg-yellow-50 bg-transparent">
                Join as Driver
              </Button>
            </Link>
            <Link href="/book">
              <Button className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">Book Now</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-yellow-50 to-yellow-100 py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
              Reliable Rides,
              <span className="text-yellow-600"> Anytime</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Experience premium taxi service with CAB 5. Professional drivers, clean vehicles, and 24/7 availability
              for all your transportation needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold text-lg px-8 py-6"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call (555) 123-TAXI
              </Button>
              <Link href="/book">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-yellow-500 text-yellow-700 hover:bg-yellow-50 bg-transparent"
                >
                  <MapPin className="mr-2 h-5 w-5" />
                  Book Online
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-foreground mb-4">Why Choose CAB 5?</h3>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We're committed to providing the best taxi experience in the city
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Clock className="h-8 w-8 text-yellow-600" />
                </div>
                <h4 className="text-2xl font-semibold mb-4">24/7 Service</h4>
                <p className="text-muted-foreground leading-relaxed">
                  Available round the clock, every day of the year. No matter when you need a ride, we're here.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="h-8 w-8 text-yellow-600" />
                </div>
                <h4 className="text-2xl font-semibold mb-4">Licensed & Insured</h4>
                <p className="text-muted-foreground leading-relaxed">
                  All our drivers are professionally licensed and our vehicles are fully insured for your safety.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Zap className="h-8 w-8 text-yellow-600" />
                </div>
                <h4 className="text-2xl font-semibold mb-4">Fast Response</h4>
                <p className="text-muted-foreground leading-relaxed">
                  Quick pickup times with real-time tracking. Get where you need to go without delay.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-foreground mb-4">Our Services</h3>
            <p className="text-xl text-muted-foreground">Comprehensive transportation solutions for every need</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <h4 className="text-xl font-semibold mb-3">City Rides</h4>
                <p className="text-muted-foreground mb-4">Quick and convenient rides around the city</p>
                <div className="text-2xl font-bold text-yellow-600">₹15/km</div>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <h4 className="text-xl font-semibold mb-3">Airport Transfer</h4>
                <p className="text-muted-foreground mb-4">Reliable airport pickup and drop-off service</p>
                <div className="text-2xl font-bold text-yellow-600">₹800 flat</div>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <h4 className="text-xl font-semibold mb-3">Hourly Service</h4>
                <p className="text-muted-foreground mb-4">Book by the hour for multiple stops</p>
                <div className="text-2xl font-bold text-yellow-600">₹600/hr</div>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <h4 className="text-xl font-semibold mb-3">Corporate</h4>
                <p className="text-muted-foreground mb-4">Business accounts with special rates</p>
                <div className="text-2xl font-bold text-yellow-600">Contact</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-black text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-4xl font-bold mb-6">Ready to Ride with CAB 5?</h3>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of satisfied customers who trust CAB 5 for their transportation needs
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold text-lg px-8 py-6"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call (555) 123-TAXI
              </Button>
              <Link href="/driver">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-black text-lg px-8 py-6 bg-transparent"
                >
                  Join as Driver
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Image src="/cab5-logo.png" alt="CAB 5 Logo" width={40} height={40} className="object-contain" />
                <span className="text-xl font-bold">CAB 5</span>
              </div>
              <p className="text-gray-400">Your trusted taxi service for reliable, safe, and comfortable rides.</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-gray-400">
                <p>Phone: (555) 123-TAXI</p>
                <p>Email: info@cab5.com</p>
                <p>24/7 Dispatch</p>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <div className="space-y-2 text-gray-400">
                <p>City Rides</p>
                <p>Airport Transfer</p>
                <p>Hourly Service</p>
                <p>Corporate Accounts</p>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Coverage Area</h4>
              <div className="space-y-2 text-gray-400">
                <p>Downtown</p>
                <p>Airport</p>
                <p>Suburbs</p>
                <p>Business District</p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 CAB 5. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
