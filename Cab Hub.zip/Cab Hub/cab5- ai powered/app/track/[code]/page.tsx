"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Navigation, Phone, ArrowLeft, Clock, User } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState, useEffect } from "react"
import { useParams } from "next/navigation"

export default function TrackingPage() {
  const params = useParams()
  const trackingCode = params.code as string
  const [bookingData, setBookingData] = useState<any>(null)
  const [cabStatus, setCabStatus] = useState("searching") // searching, assigned, arriving, arrived, in-transit, completed
  const [driverInfo, setDriverInfo] = useState({
    name: "Rajesh Kumar",
    phone: "+91 98765 43210",
    rating: 4.8,
    vehicleNumber: "MH 01 AB 1234",
  })
  const [estimatedTime, setEstimatedTime] = useState(8)
  const [distance, setDistance] = useState("2.3 km")
  const [tripDistance, setTripDistance] = useState("12.5 km")
  const [tripTime, setTripTime] = useState("25 min")

  useEffect(() => {
    // Get booking data from sessionStorage
    const storedData = sessionStorage.getItem("bookingData")
    if (storedData) {
      setBookingData(JSON.parse(storedData))
    }

    // Simulate cab status updates
    const statusUpdates = [
      { status: "searching", time: 0 },
      { status: "assigned", time: 2000 },
      { status: "arriving", time: 4000 },
      { status: "arrived", time: 15000 },
    ]

    statusUpdates.forEach(({ status, time }) => {
      setTimeout(() => {
        setCabStatus(status)
        if (status === "arriving") {
          // Start countdown
          let timeLeft = estimatedTime
          const countdown = setInterval(() => {
            timeLeft -= 1
            setEstimatedTime(timeLeft)
            if (timeLeft <= 0) {
              clearInterval(countdown)
              setCabStatus("arrived")
            }
          }, 60000) // Update every minute
        }
      }, time)
    })
  }, [])

  const getStatusMessage = () => {
    switch (cabStatus) {
      case "searching":
        return "Searching for nearby drivers..."
      case "assigned":
        return "Driver assigned! Cab is on the way"
      case "arriving":
        return `Driver is arriving in ${estimatedTime} minutes`
      case "arrived":
        return "Your cab has arrived at pickup location!"
      case "in-transit":
        return "Trip in progress to destination"
      case "completed":
        return "Trip completed successfully!"
      default:
        return "Processing your request..."
    }
  }

  const getStatusColor = () => {
    switch (cabStatus) {
      case "searching":
        return "bg-blue-500"
      case "assigned":
        return "bg-yellow-500"
      case "arriving":
        return "bg-orange-500"
      case "arrived":
        return "bg-green-500"
      case "in-transit":
        return "bg-purple-500"
      case "completed":
        return "bg-green-600"
      default:
        return "bg-gray-500"
    }
  }

  if (!bookingData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-4">Loading booking details...</h2>
            <p className="text-muted-foreground">Tracking Code: {trackingCode}</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/cab5-logo.png" alt="CAB 5 Logo" width={60} height={60} className="object-contain" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">CAB 5</h1>
              <p className="text-sm text-muted-foreground">Premium Taxi Service</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-yellow-600" />
              <span className="font-semibold">Call: (555) 123-TAXI</span>
            </div>
            <Link href="/book">
              <Button variant="outline" className="border-yellow-500 text-yellow-700 hover:bg-yellow-50 bg-transparent">
                <ArrowLeft className="mr-2 h-4 w-4" />
                New Booking
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Tracking Code */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Track Your Ride</h1>
            <div className="flex items-center justify-center gap-2">
              <span className="text-lg text-muted-foreground">Booking Code:</span>
              <Badge variant="outline" className="text-lg px-4 py-2 font-mono font-bold">
                {trackingCode}
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Map Section */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-yellow-600" />
                  Live Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Simulated Map */}
                <div className="bg-gray-100 rounded-lg h-80 flex items-center justify-center mb-4 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100"></div>
                  <div className="relative z-10 text-center">
                    <div className="mb-4">
                      <div className="w-4 h-4 bg-green-500 rounded-full mx-auto mb-2 animate-pulse"></div>
                      <p className="text-sm font-semibold">Your Location</p>
                    </div>
                    <div className="mb-4">
                      <div className="w-6 h-6 bg-yellow-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                        🚗
                      </div>
                      <p className="text-sm font-semibold">Cab Location</p>
                      <p className="text-xs text-muted-foreground">{distance} away</p>
                    </div>
                    <div>
                      <div className="w-4 h-4 bg-red-500 rounded-full mx-auto mb-2"></div>
                      <p className="text-sm font-semibold">Destination</p>
                    </div>
                  </div>
                </div>

                {/* Status */}
                <div className="text-center">
                  <div
                    className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-white font-semibold ${getStatusColor()}`}
                  >
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                    {getStatusMessage()}
                  </div>
                </div>

                {/* Trip Info */}
                {cabStatus === "in-transit" && (
                  <div className="mt-6 p-4 bg-purple-50 rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Navigation className="h-4 w-4 text-purple-600" />
                      Trip Progress
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Distance:</span>
                        <span className="font-semibold ml-2">{tripDistance}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Est. Time:</span>
                        <span className="font-semibold ml-2">{tripTime}</span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Booking Details */}
            <div className="space-y-6">
              {/* Driver Info */}
              {cabStatus !== "searching" && (
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5 text-yellow-600" />
                      Your Driver
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                        <User className="h-8 w-8 text-gray-500" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{driverInfo.name}</h3>
                        <p className="text-muted-foreground">⭐ {driverInfo.rating} rating</p>
                        <p className="text-sm font-mono">{driverInfo.vehicleNumber}</p>
                      </div>
                    </div>
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      <Phone className="mr-2 h-4 w-4" />
                      Call Driver: {driverInfo.phone}
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Booking Summary */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Navigation className="h-5 w-5 text-green-600 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-semibold">Pickup</p>
                        <p className="text-sm text-muted-foreground">{bookingData.pickupLocation}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-red-600 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-semibold">Drop-off</p>
                        <p className="text-sm text-muted-foreground">{bookingData.dropoffLocation}</p>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date & Time:</span>
                      <span className="font-semibold">
                        {bookingData.rideDate} at {bookingData.rideTime}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Passengers:</span>
                      <span className="font-semibold">{bookingData.passengers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Vehicle:</span>
                      <span className="font-semibold">{bookingData.vehicleType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Payment:</span>
                      <span className="font-semibold">{bookingData.paymentMethod}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* ETA Card */}
              {cabStatus === "arriving" && (
                <Card className="shadow-lg border-orange-200">
                  <CardContent className="p-6 text-center">
                    <Clock className="h-12 w-12 text-orange-500 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-orange-600 mb-2">{estimatedTime} minutes</h3>
                    <p className="text-muted-foreground">Estimated arrival time</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline" className="border-red-500 text-red-600 hover:bg-red-50 bg-transparent">
              Cancel Ride
            </Button>
            <Button className="bg-yellow-500 hover:bg-yellow-600 text-black">
              <Phone className="mr-2 h-4 w-4" />
              Call Support
            </Button>
            {cabStatus === "arrived" && (
              <Button className="bg-green-600 hover:bg-green-700" onClick={() => setCabStatus("in-transit")}>
                Start Trip
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
